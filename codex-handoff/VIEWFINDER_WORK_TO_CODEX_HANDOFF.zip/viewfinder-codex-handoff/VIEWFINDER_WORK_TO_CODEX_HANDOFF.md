# VIEWFINDER - HANDOFF WORK VERS CODEX

## 0. Objet et limites

Ce dossier permet à Codex de reprendre exactement la correction de fidélité du pipeline image V3 sans accès aux conversations Work.

Il ne demande aucune refonte et ne contient aucun secret. Work n'a effectué aucun commit, push, déploiement, appel OpenAI Images ou opération payante.

Périmètre immédiat de Codex :

1. comparer ce dossier au `main` réel ;
2. appliquer ou reproduire exactement le patch ;
3. réexécuter les tests ;
4. contrôler l'absence de secret ;
5. commit/push selon le workflow GitHub existant ;
6. déployer sur l'environnement Viewfinder de test ;
7. effectuer une seule génération Golden Test en Production / qualité haute ;
8. restituer la traçabilité complète, sans corriger automatiquement le résultat.

## 1. Identité exacte du projet

- Repository : `fabienducant-dot/viewfinder`
- Branche de référence : `main`
- Commit de départ audité : `89b30c2eb5f28a4f22ddeb4e0d491a75a5cb3efb`
- Version observée : `3.2.1-index-integrity`
- Message du commit : `Repair corrupted Viewfinder entrypoint`

Toutes les modifications de ce dossier ont été construites à partir de cet état.

Vérification Work du 18 août 2026 : la tête visible de `main` est toujours exactement `89b30c2eb5f28a4f22ddeb4e0d491a75a5cb3efb`. Aucun changement amont plus récent n'a été observé au moment de créer ce handoff. Codex doit néanmoins refaire cette vérification avant application.

## 2. Pipeline V3 réellement utilisé

Le flux normal actuel est :

```text
Demande utilisateur
-> prepareAuthoritativeV3()
-> fonction Netlify plan-v3
-> planV3()
-> inferSubjectBrief()
-> createArtDirectionBrief()
-> buildPosterStrategy()
-> buildPhotoBrief()
-> v3Plan.photoBrief.prompt
-> create-image-job.js
-> process-image-job-background.js
-> OpenAI Images
-> analyse/contrôle vision V3
-> Sharp / brand-compositor
-> résultat final Viewfinder
```

Points critiques :

- `buildFinalImagePrompt()` n'est pas le constructeur du flux normal V3.
- Le prompt réellement transmis au modèle image est `v3Plan.photoBrief.prompt`.
- Ce prompt est construit par `buildPhotoBrief()` dans `netlify/functions/_shared/v3-art-direction.js`.
- `create-image-job.js` remplace le prompt client par `v3Plan.photoBrief.prompt` lorsqu'un plan V3 est fourni.
- `process-image-job-background.js` appelle ensuite OpenAI Images, conserve l'image brute, lance le contrôle V3, puis le compositor Sharp.

Ne pas repartir d'une ancienne hypothèse V2.

## 3. Cause principale

Avant correction, l'intention utilisateur était successivement classée, raccourcie, interprétée et transformée en manifestations génériques. Elle était ensuite insérée dans une direction artistique fixe beaucoup plus volumineuse.

Problèmes constatés :

- `conciseTheme()` réduisait certaines demandes à 8 ou 9 mots ;
- la demande complète n'était pas garantie dans le prompt final ;
- `userConstraints` restait vide ;
- certains objets, actions, scènes, cadrages ou zones corporelles pouvaient disparaître ;
- une seule zone corporelle demandée était parfois conservée ;
- les trois lieux historiques - pavillon lacustre, galerie d'obsidienne, cabinet noir - devenaient trop prescriptifs ;
- le fantastique ou l'architecture pouvaient dominer le sujet ;
- les interdits étaient répétés ;
- le contrat praticien pouvait demander une identité `Fabien` sans photographie humaine réellement envoyée ;
- l'ancien contrôle de cohérence favorisait indirectement les formulations courtes ;
- les blocs SDZ fixes étaient beaucoup plus volumineux que la demande.

Conséquence : OpenAI Images recevait surtout une affiche SDZ noire et dorée, tandis que le contenu précis demandé devenait secondaire.

## 4. Principe architectural à préserver

**L'intention utilisateur pilote la scène. La direction artistique SDZ habille cette scène ; elle ne la remplace jamais.**

Hiérarchie :

1. demande utilisateur exacte ;
2. sujet, personnes, action, objets, décor, cadrage et transformation dérivés de cette demande ;
3. direction artistique SDZ appliquée au sujet ;
4. contraintes techniques : format, zones Sharp, anatomie, absence de texte ou logo généré.

La DA SDZ n'est plus un générateur de sujet. Elle est un langage visuel.

## 5. Modifications réellement effectuées

Quatre fichiers de code sont concernés. Le quatrième, `v3-creative-strategy.js`, est indispensable même s'il n'était pas cité dans la liste minimale initiale.

### 5.1 `netlify/functions/_shared/v3-creative-strategy.js`

Avant :

- demandes service/transformation/editorial tronquées à 8-9 mots ;
- `userConstraints: []` ;
- pas de champ garantissant la demande complète ;
- une seule zone corporelle détectée ;
- douleur et mental pouvaient être confondus ;
- scène explicite réduite à un mot.

Après :

- conservation de la demande nettoyée dans `exactUserRequest` ;
- limitation de sécurité à 320 caractères seulement, au lieu de 8-9 mots ;
- `userConstraints` contient une obligation explicite de représenter la demande ;
- `buildSubjectVisualDirective()` traduit séparément :
  - douleur/blocage/lourdeur : contrainte puis ouverture/amplitude ;
  - mental/stress/lâcher-prise : premier plan dense puis perspective calme ;
  - prestation : action métier et matériel reconnaissables ;
  - sujet générique : scène concrète, sans prestation inventée ;
- toutes les zones corporelles explicitement retrouvées sont conservées ;
- la demande exacte est ajoutée au sujet visuel principal ;
- les fonctions utiles au test sont exportées.

Impact attendu : le contenu spécifique arrive intact et prioritaire dans le constructeur photographique.

### 5.2 `netlify/functions/_shared/v3-art-direction.js`

Avant :

- prompt monolithique très long ;
- univers sélectionné présenté comme décor imposé ;
- ratio rigide soin/personnes/geste 70 %, décor 30 % ;
- Story réservant explicitement les 30 % inférieurs ;
- fantastique périphérique répétitif ;
- interdits concaténés avec doublons ;
- praticien demandé comme `Fabien` sans signal de référence humaine ;
- post-traitement générique par remplacements textuels fragiles.

Après :

- un seul constructeur réel : `buildPhotoBrief()` ;
- `buildResolvedPhotoBrief()` délègue directement à ce constructeur ;
- prompt structuré :
  1. priorité demande utilisateur ;
  2. scène et prestation ;
  3. direction artistique SDZ ;
  4. composition ;
  5. réalisme/anatomie ;
  6. interdits ;
  7. sortie brute pour Sharp ;
- socle centralisé dans `SDZ_VISUAL_FOUNDATION` ;
- interdits permanents centralisés ;
- `relevantExclusions()` déduplique les interdits et n'ajoute que les exclusions métier pertinentes ;
- exclusions ambiguës clarifiées : par exemple les pierres de soin sont interdites sans interdire la pierre architecturale ;
- suppression totale du ratio 70/30 ;
- composition cinématographique globale : sujet identifiable et décor narratif ;
- les trois anciens lieux ne sont plus inclus comme décor obligatoire dans le prompt envoyé ;
- environnement construit avec `composedEnvironmentDirective()` à partir de la demande ;
- vocabulaire ouvert : architecture intime/monumentale, temple ou pavillon si demandé, terrasse, galerie, espace minéral, eau, paysage, horizon, montagnes, ciel, brume et volumes crédibles ;
- fantastique contextuel : architecture, échelle, paysage, lumière, profondeur, matières, eau/reflets, brume ou ouverture ;
- interdiction du fantastique kitsch, magie visible, occultisme, rayon énergétique et portail central ;
- praticien sans référence : homme adulte, tenue noire professionnelle, apparence naturelle ; aucune ressemblance réelle inventée ;
- maintien des règles spécifiques PSiO, personnes, gestes, positions et matériels du registre V3 ;
- séparation stricte scène/branding : aucun logo, texte, CTA, URL ou fausse typographie générés ;
- zone Sharp formulée selon le template réel, sans annoncer une adaptation inexistante.

Impact attendu : le sujet pilote la scène ; SDZ apporte la forme cinématographique sans transformer toutes les demandes en même décor.

### 5.3 `netlify/functions/_shared/v3-consistency-control.js`

Avant :

- une demande complète avec ponctuation pouvait échouer au contrôle `subjectMeaningIsExplicit` ;
- la validation exigeait que le prompt photographique contienne exactement le lieu, l'architecture, la lumière et le phénomène du petit catalogue sélectionné.

Après :

- la signification est validée par présence réelle du thème complet dans la manifestation ;
- le prompt photographique est validé sur l'environnement composé, le fantastique et les matières ;
- le contrôle ne réimpose plus les trois lieux historiques dans le texte envoyé à OpenAI ;
- les autres contrôles V3 restent en place.

Impact attendu : validation compatible avec une intention complète et un décor composé librement.

### 5.4 `tests/v3-prompt-construction.test.js`

Nouveau fichier.

Il construit les sept cas de référence sans appeler OpenAI et vérifie le prompt effectivement destiné à `create-image-job`.

Cas :

1. Massage Zébré ;
2. Massage Ayurvédique Abhyanga ;
3. Reiki ;
4. Luminothérapie PSiO ;
5. Massage japonais du visage ;
6. douleurs/blocages génériques ;
7. mental/lâcher-prise générique.

### 5.5 `final-prompts.txt`

Artefact de contrôle, pas un fichier fonctionnel nécessaire au runtime.

Il contient les sept prompts finaux complets produits par le code testé.

## 6. Contenu du dossier

- `VIEWFINDER_WORK_TO_CODEX_HANDOFF.md` : ce document ;
- `viewfinder-v3-intent-fix.patch` : unified diff complet depuis le commit de base ;
- `final-files/netlify/functions/_shared/v3-creative-strategy.js` ;
- `final-files/netlify/functions/_shared/v3-art-direction.js` ;
- `final-files/netlify/functions/_shared/v3-consistency-control.js` ;
- `final-files/tests/v3-prompt-construction.test.js` ;
- `final-prompts.txt` ;
- `TEST_RESULTS.txt` ;
- `SHA256SUMS.txt`.

Le patch a été validé en dry-run contre les fichiers exacts du commit de base.

## 7. Application proposée à Codex

Depuis un checkout propre de `fabienducant-dot/viewfinder` :

```bash
git fetch origin
git switch main
git pull --ff-only
git rev-parse HEAD
git apply --check /chemin/vers/viewfinder-v3-intent-fix.patch
git apply /chemin/vers/viewfinder-v3-intent-fix.patch
```

Le `git rev-parse HEAD` doit idéalement retourner :

```text
89b30c2eb5f28a4f22ddeb4e0d491a75a5cb3efb
```

Si la branche a évolué ou si `git apply --check` échoue, arrêter avant modification et documenter les conflits. Ne pas recréer la logique de mémoire.

## 8. Tests

Répertoire Work utilisé :

```text
/workspace/scratch/919d98b928b3/viewfinder-prompt-fix
```

Environnement :

```text
Node v24.19.0
```

Commandes exactes :

```bash
node --check netlify/functions/_shared/v3-creative-strategy.js
node --check netlify/functions/_shared/v3-art-direction.js
node --check netlify/functions/_shared/v3-consistency-control.js
node --test tests/v3-prompt-construction.test.js
```

Dernier résultat Work :

```text
tests 15
pass 15
fail 0
cancelled 0
skipped 0
todo 0
```

Couverture :

- demande exacte conservée et prioritaire ;
- absence du ratio 70/30 ;
- absence des trois anciens décors obligatoires dans le prompt ;
- environnement composé selon le sujet ;
- fantastique narratif et crédible ;
- prévention d'une ressemblance humaine inventée ;
- gestes, personnes, matériel et zones corporelles métier ;
- fidélité produit PSiO dans le texte du prompt ;
- interdits permanents présents et dédupliqués ;
- zone calme compatible avec Sharp ;
- absence de logo/texte demandé au modèle ;
- contrôle de cohérence V3 accepté pour les sept cas ;
- `create-image-job.js` utilise `v3Plan.photoBrief.prompt` ;
- absence de `buildFinalImagePrompt()` dans le chemin d'envoi testé.

Codex doit exécuter les mêmes commandes après application.

## 9. Éléments non modifiés

- `netlify/functions/_shared/brand-compositor.js` : non modifié ;
- Sharp : non modifié ;
- Make : non modifié ;
- génération de texte : non modifiée ;
- pipeline campagne : non refondu ;
- couches V2 : non supprimées ;
- aucune nouvelle fonctionnalité ;
- aucune génération OpenAI Images ;
- aucune opération payante ;
- aucun déploiement ;
- aucun commit ou push.

Les fichiers matérialisés localement mais inchangés, comme `v3-pipeline.js`, `v3-registry.js`, `v3-art-worlds.js` et `create-image-job.js`, ne figurent pas dans le patch.

## 10. Contrainte Sharp connue - ne pas corriger maintenant

Le compositor V3 utilise des zones fixes par plateforme quand `posterStrategy` est fourni.

Pour Story :

- texte : environ 61-72 % de la hauteur ;
- logo : environ 75-82 % ;
- emplacement principal : partie basse.

La mention rigide `30 % inférieurs` a été supprimée du prompt, mais la photographie doit encore réserver une zone basse calme compatible avec Sharp pour une Story.

Les autres formats ont leurs zones fixes supérieures, inférieures ou latérales.

Une vraie adaptation à l'image nécessiterait de faire remonter `calmZones` dans le choix des zones de `posterStrategy` et dans le compositor. Ce chantier est hors périmètre jusqu'à l'évaluation de l'image brute.

**Codex ne doit pas modifier Sharp avant le Golden Test.**

## 11. Golden Test après publication

Ne l'effectuer qu'après :

1. application du patch ;
2. tests réussis ;
3. commit/push ;
4. déploiement vérifié ;
5. confirmation normale du coût et du plafond.

Demande utilisateur exacte :

```text
Douleurs dorsales, blocage, sensations de lourdeur. Fond paysage fantastique, cinématographique, architectural. Temple donnant vue sur un paysage féerique.
```

Paramètres :

- format : Story 9:16 ;
- mode : Production ;
- qualité : haute ;
- nombre maximal : **une seule génération OpenAI Images**.

Attendus :

- lourdeur/blocage perceptible dans l'état initial ;
- temple réellement visible ;
- temple ouvert sur un paysage féerique ;
- profondeur cinématographique ;
- progression vers lumière, espace et libération ;
- noir profond mais détaillé ;
- or noble et lumineux ;
- environnement spectaculaire mais crédible ;
- émotion compréhensible avant lecture.

Temple, paysage et fantastique sont obligatoires uniquement parce qu'ils sont explicitement demandés dans ce test. Ils ne doivent pas être codés comme constantes globales.

Si le processus échoue avant l'appel OpenAI, arrêter et fournir l'erreur exacte. Ne pas modifier le code et ne pas relancer.

## 12. Traçabilité du Golden Test

Conserver et restituer :

1. `USER REQUEST` exact ;
2. `FINAL IMAGE PROMPT` exact ;
3. modèle ;
4. taille ;
5. qualité ;
6. mode de coût et confirmations ;
7. références réellement envoyées, avec rôles, sans exposer leurs données privées ;
8. image brute OpenAI avant Sharp ;
9. verdict complet du contrôle V3 ;
10. image finale après Sharp ;
11. compteur réel d'appels image.

L'image brute doit être examinée en premier afin de séparer :

- fidélité du prompt et du modèle ;
- effet du compositor Sharp.

Ne corriger automatiquement aucun résultat, même mauvais. Présenter l'écart puis attendre la décision de Fabien.

## 13. Backlog technique - ne pas corriger maintenant

Ces risques ont été identifiés pendant l'audit. Ils ne doivent pas être mélangés avec la correction actuelle de fidélité image.

- jobs pouvant rester `queued` sans mécanisme de timeout utilisateur complet ;
- contrôle métier ou qualité potentiellement contourné dans certains replis ou statuts ;
- revue de sécurité des endpoints capables de déclencher un coût ;
- risque `generate-text` / construction de `baseUrl` à revalider séparément ;
- idempotence : clés et jobs échoués pouvant produire des comportements durables inattendus ;
- absence de retry applicatif contrôlé pour certaines erreurs transitoires ; les retries Netlify sont volontairement neutralisés pour éviter un second coût ;
- campagne ne réutilisant pas nécessairement une photographie maîtresse ;
- anciennes couches V2, fonctions historiques et code mort ;
- éventuels logs à revoir pour garantir qu'aucune donnée sensible n'est exposée ;
- Make et ses webhooks ;
- diversité du catalogue interne/fingerprints au-delà de ce que reçoit le prompt ;
- adaptation dynamique des zones Sharp via `calmZones`.

Ces problèmes sont connus. **Ne pas les corriger maintenant.**

## 14. Instruction finale à Codex

**CODEX : ne refais pas Viewfinder.**

Ne remplace pas cette correction par une autre architecture.

Commence par comparer le patch avec le `main` actuel.

Si le commit de base est toujours compatible, applique ou reproduis exactement les modifications de Work.

Réexécute les tests.

Si les tests passent, vérifie l'absence de secret, puis commit et push sur une branche dédiée ou selon le workflow GitHub existant.

Vérifie ensuite le déploiement Netlify.

N'effectue qu'ensuite le Golden Test demandé, avec une seule génération payante.

Si tu constates un conflit entre le repository actuel et ce handoff, arrête-toi et documente précisément le conflit avant de modifier la logique.

Après le Golden Test, restitue le prompt exact, l'image brute, le verdict, l'image finale et l'analyse de l'écart, puis arrête-toi.

